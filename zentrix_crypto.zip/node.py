#!/usr/bin/env python3
"""Zentrix (ZTX) Blockchain Node Server"""

from flask import Flask, jsonify, request
import argparse
import threading
import time
from utils import Blockchain, Transaction, Block
from utils.p2p import P2PNetwork

app = Flask(__name__)
blockchain = None
p2p = None
node_address = None

@app.route('/chain', methods=['GET'])
def get_chain():
    return jsonify(blockchain.to_dict()), 200

@app.route('/getwork', methods=['GET'])
def get_work():
    miner_address = request.args.get('address')
    if not miner_address:
        return jsonify({'error': 'Missing address parameter'}), 400
    template = blockchain.get_next_block_template(miner_address)
    return jsonify(template), 200

@app.route('/submit', methods=['POST'])
def submit_block():
    block_data = request.get_json()
    if not block_data:
        return jsonify({'error': 'Invalid block data'}), 400

    success, message = blockchain.submit_block(block_data)

    if success:
        block = Block.from_dict(block_data)
        if p2p:
            threading.Thread(target=p2p.broadcast_block, args=(block,)).start()
        return jsonify({
            'message': message,
            'block_index': block_data['index'],
            'hash': block_data['hash']
        }), 201
    else:
        return jsonify({'error': message}), 400

@app.route('/tx', methods=['POST'])
def new_transaction():
    tx_data = request.get_json()
    if not tx_data:
        return jsonify({'error': 'Invalid transaction data'}), 400

    tx = Transaction.from_dict(tx_data)
    success, result = blockchain.add_transaction(tx)

    if success:
        if p2p:
            threading.Thread(target=p2p.broadcast_transaction, args=(tx,)).start()
        return jsonify({
            'message': 'Transaction added',
            'tx_id': result
        }), 201
    else:
        return jsonify({'error': result}), 400

@app.route('/balance', methods=['POST'])
def get_balance():
    data = request.get_json()
    if not data or 'address' not in data:
        return jsonify({'error': 'Missing address'}), 400
    address = data['address']
    balance = blockchain.get_balance(address)
    return jsonify({'address': address[:40] + '...', 'balance': balance}), 200

@app.route('/price', methods=['GET'])
def get_price():
    return jsonify(blockchain.get_price_data()), 200

@app.route('/exchange/buy', methods=['POST'])
def buy_ztx():
    data = request.get_json()
    usd_amount = data.get('usd_amount')
    if not usd_amount or usd_amount <= 0:
        return jsonify({'error': 'Invalid USD amount'}), 400

    ztx_amount, message = blockchain.swap_usd_to_ztx(usd_amount)
    if ztx_amount:
        return jsonify({
            'ztx_amount': ztx_amount,
            'usd_spent': usd_amount,
            'price_per_ztx': usd_amount / ztx_amount
        }), 200
    return jsonify({'error': message}), 400

@app.route('/exchange/sell', methods=['POST'])
def sell_ztx():
    data = request.get_json()
    ztx_amount = data.get('ztx_amount')
    if not ztx_amount or ztx_amount <= 0:
        return jsonify({'error': 'Invalid ZTX amount'}), 400

    usd_amount, message = blockchain.swap_ztx_to_usd(ztx_amount)
    if usd_amount:
        return jsonify({
            'usd_amount': usd_amount,
            'ztx_sold': ztx_amount,
            'price_per_ztx': usd_amount / ztx_amount
        }), 200
    return jsonify({'error': message}), 400

@app.route('/exchange/depth', methods=['GET'])
def market_depth():
    return jsonify({
        'ztx_reserve': blockchain.liquidity_ztx,
        'usd_reserve': blockchain.liquidity_usd,
        'constant_product': blockchain.constant_product
    }), 200

@app.route('/nodes', methods=['GET'])
def get_nodes():
    return jsonify({'nodes': p2p.get_peers() if p2p else []}), 200

@app.route('/nodes/register', methods=['POST'])
def register_node():
    values = request.get_json()
    node = values.get('node')
    if not node:
        return jsonify({'error': 'Missing node'}), 400

    if p2p and p2p.register_node(node):
        return jsonify({'message': 'Node added', 'nodes': p2p.get_peers()}), 201
    return jsonify({'error': 'Failed to add node'}), 400

@app.route('/nodes/resolve', methods=['GET'])
def consensus():
    if p2p:
        replaced = p2p.sync_chains(blockchain)
        return jsonify({
            'message': 'Chain updated' if replaced else 'Chain is authoritative',
            'length': len(blockchain.chain)
        }), 200
    return jsonify({'error': 'P2P not initialized'}), 500

@app.route('/info', methods=['GET'])
def node_info():
    return jsonify({
        'difficulty': blockchain.difficulty,
        'blocks': len(blockchain.chain),
        'pending_txs': len(blockchain.pending_transactions),
        'peers': len(p2p.get_peers()) if p2p else 0,
        'mining_reward': blockchain.mining_reward,
        'token': blockchain.token_symbol,
        'price': blockchain.get_price_data()
    }), 200

def sync_task():
    while True:
        time.sleep(30)
        if p2p:
            try:
                p2p.sync_chains(blockchain)
            except:
                pass

def main():
    global blockchain, p2p, node_address

    parser = argparse.ArgumentParser(description='Zentrix (ZTX) Blockchain Node')
    parser.add_argument('-p', '--port', type=int, default=5000)
    parser.add_argument('-H', '--host', default='0.0.0.0')
    parser.add_argument('--seed')
    args = parser.parse_args()

    blockchain = Blockchain()
    node_address = f"http://{args.host}:{args.port}"
    p2p = P2PNetwork(node_address)

    if args.seed:
        print(f"Connecting to seed node: {args.seed}")
        p2p.register_node(args.seed)
        p2p.discover_peers(args.seed)
        p2p.sync_chains(blockchain)

    sync_thread = threading.Thread(target=sync_task, daemon=True)
    sync_thread.start()

    print(f"Zentrix (ZTX) Node starting on {args.host}:{args.port}")
    print(f"Token: {blockchain.token_name} ({blockchain.token_symbol})")
    print(f"Difficulty: {blockchain.difficulty}")
    print(f"Mining Reward: {blockchain.mining_reward} {blockchain.token_symbol}")
    print(f"Initial Price: ${blockchain.base_price}")

    app.run(host=args.host, port=args.port, threaded=True)

if __name__ == "__main__":
    main()
