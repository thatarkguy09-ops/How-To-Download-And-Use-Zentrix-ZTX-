#!/usr/bin/env python3
"""Zentrix (ZTX) Exchange"""

import argparse
import requests

def get_price(node_url):
    try:
        r = requests.get(f"{node_url}/price")
        if r.status_code == 200:
            data = r.json()
            print(f"\nZentrix (ZTX) Market Data:")
            print(f"Price: ${data['price_usd']:.4f}")
            print(f"DEX Price: ${data['dex_price']:.4f}")
            print(f"Supply: {data['total_supply']:,} ZTX")
            print(f"Market Cap: ${data['market_cap']:,.2f}")
            print(f"Liquidity: {data['liquidity_ztx']:,.0f} ZTX / ${data['liquidity_usd']:,.0f}")
    except Exception as e:
        print(f"Error: {e}")

def buy_ztx(node_url, usd_amount):
    try:
        r = requests.post(f"{node_url}/exchange/buy", json={"usd_amount": float(usd_amount)})
        if r.status_code == 200:
            data = r.json()
            print(f"\nPurchase Successful!")
            print(f"Spent: ${usd_amount} USD")
            print(f"Received: {data['ztx_amount']:.4f} ZTX")
            print(f"Price: ${data['price_per_ztx']:.4f}/ZTX")
        else:
            print(f"Error: {r.json().get('error')}")
    except Exception as e:
        print(f"Error: {e}")

def sell_ztx(node_url, ztx_amount):
    try:
        r = requests.post(f"{node_url}/exchange/sell", json={"ztx_amount": float(ztx_amount)})
        if r.status_code == 200:
            data = r.json()
            print(f"\nSale Successful!")
            print(f"Sold: {ztx_amount} ZTX")
            print(f"Received: ${data['usd_amount']:.4f} USD")
            print(f"Price: ${data['price_per_ztx']:.4f}/ZTX")
        else:
            print(f"Error: {r.json().get('error')}")
    except Exception as e:
        print(f"Error: {e}")

def market_depth(node_url):
    try:
        r = requests.get(f"{node_url}/exchange/depth")
        if r.status_code == 200:
            data = r.json()
            print(f"\nLiquidity Pool:")
            print(f"ZTX Reserve: {data['ztx_reserve']:,.2f}")
            print(f"USD Reserve: ${data['usd_reserve']:,.2f}")
    except Exception as e:
        print(f"Error: {e}")

def main():
    parser = argparse.ArgumentParser(description='Zentrix (ZTX) Exchange')
    parser.add_argument('--node', default='http://localhost:5000')
    parser.add_argument('command', choices=['price', 'buy', 'sell', 'depth'])
    parser.add_argument('--amount', type=float)

    args = parser.parse_args()

    if args.command == 'price':
        get_price(args.node)
    elif args.command == 'buy':
        if not args.amount:
            print("Please specify --amount (USD to spend)")
            return
        buy_ztx(args.node, args.amount)
    elif args.command == 'sell':
        if not args.amount:
            print("Please specify --amount (ZTX to sell)")
            return
        sell_ztx(args.node, args.amount)
    elif args.command == 'depth':
        market_depth(args.node)

if __name__ == "__main__":
    main()
