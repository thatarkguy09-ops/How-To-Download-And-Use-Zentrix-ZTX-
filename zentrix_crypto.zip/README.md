# Zentrix (ZTX) Blockchain

Complete Python cryptocurrency with integrated DEX and price tracking.

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Start 3 Nodes (3 separate terminals)
```bash
# Terminal 1 - Genesis Node
python node.py -p 5000

# Terminal 2 - Peer 1
python node.py -p 5001 --seed http://localhost:5000

# Terminal 3 - Peer 2
python node.py -p 5002 --seed http://localhost:5000
```

### 3. Create Wallet (Terminal 4)
```bash
python wallet.py create
```
Save your address!

### 4. Start Mining (Terminal 5)
```bash
python miner.py --node http://localhost:5000 --address YOUR_ADDRESS
```

### 5. Check Price & Balance
```bash
python wallet.py price --node http://localhost:5000
```

## Commands

**Wallet:**
- `python wallet.py create` - Create new wallet
- `python wallet.py balance` - Check ZTX balance
- `python wallet.py price` - Check price + portfolio value
- `python wallet.py send --to ADDRESS --amount 50` - Send ZTX

**Exchange:**
- `python exchange.py price` - Market data
- `python exchange.py buy --amount 100` - Buy ZTX with $100
- `python exchange.py sell --amount 500` - Sell 500 ZTX
- `python exchange.py depth` - Liquidity pool info

**Mining:**
- `python miner.py --address YOUR_KEY` - CPU mine
- `python miner.py --address YOUR_KEY --threads 8` - Use 8 threads

## Tokenomics

- **Name**: Zentrix
- **Symbol**: ZTX
- **Block Reward**: 100 ZTX
- **Starting Price**: $0.01
- **Price Formula**: $0.01 + (Supply × $0.0001)
- **Difficulty**: Adjusts every 10 blocks

## API Endpoints

- `GET /price` - ZTX price and market data
- `POST /balance` - Check balance (JSON: {"address": "..."})
- `POST /exchange/buy` - Buy ZTX (JSON: {"usd_amount": 100})
- `POST /exchange/sell` - Sell ZTX (JSON: {"ztx_amount": 50})
- `GET /chain` - Full blockchain

## Project Structure

```
crypto_project/
├── node.py          # Blockchain node
├── miner.py         # Mining software
├── wallet.py        # Wallet CLI
├── exchange.py      # DEX trading
├── utils/           # Core blockchain code
└── requirements.txt # Dependencies
```

Happy mining! ⛏️
