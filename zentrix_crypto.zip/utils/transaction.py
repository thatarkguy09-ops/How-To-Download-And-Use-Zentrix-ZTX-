import time
import json
from .crypto_utils import sha256_hash, verify_signature

class Transaction:
    def __init__(self, sender, recipient, amount, fee=0.001, signature=None, timestamp=None):
        self.sender = sender
        self.recipient = recipient
        self.amount = amount
        self.fee = fee
        self.timestamp = timestamp or time.time()
        self.signature = signature
        self.tx_id = self.calculate_hash()

    def calculate_hash(self):
        data = {
            'sender': self.sender,
            'recipient': self.recipient,
            'amount': self.amount,
            'fee': self.fee,
            'timestamp': self.timestamp
        }
        return sha256_hash(data)

    def to_dict(self):
        return {
            'sender': self.sender,
            'recipient': self.recipient,
            'amount': self.amount,
            'fee': self.fee,
            'timestamp': self.timestamp,
            'signature': self.signature,
            'tx_id': self.tx_id
        }

    @classmethod
    def from_dict(cls, data):
        tx = cls(
            sender=data['sender'],
            recipient=data['recipient'],
            amount=data['amount'],
            fee=data.get('fee', 0.001),
            signature=data.get('signature'),
            timestamp=data.get('timestamp')
        )
        return tx

    def is_valid(self):
        if self.sender == "0":
            return True
        if not self.signature:
            return False
        data = {
            'sender': self.sender,
            'recipient': self.recipient,
            'amount': self.amount,
            'fee': self.fee,
            'timestamp': self.timestamp
        }
        return verify_signature(self.sender, self.signature, data)
