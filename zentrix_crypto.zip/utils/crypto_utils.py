import hashlib
import json
from ecdsa import SigningKey, SECP256k1, VerifyingKey
import base64

def sha256_hash(data):
    if isinstance(data, dict):
        data = json.dumps(data, sort_keys=True).encode()
    elif isinstance(data, str):
        data = data.encode()
    return hashlib.sha256(data).hexdigest()

def generate_keypair():
    sk = SigningKey.generate(curve=SECP256k1)
    vk = sk.get_verifying_key()
    return {
        'private_key': base64.b64encode(sk.to_string()).decode('ascii'),
        'public_key': base64.b64encode(vk.to_string()).decode('ascii')
    }

def sign_transaction(private_key, transaction_data):
    sk = SigningKey.from_string(base64.b64decode(private_key), curve=SECP256k1)
    tx_string = json.dumps(transaction_data, sort_keys=True).encode()
    signature = sk.sign(tx_string)
    return base64.b64encode(signature).decode('ascii')

def verify_signature(public_key, signature, transaction_data):
    try:
        vk = VerifyingKey.from_string(base64.b64decode(public_key), curve=SECP256k1)
        tx_string = json.dumps(transaction_data, sort_keys=True).encode()
        return vk.verify(base64.b64decode(signature), tx_string)
    except:
        return False

def merkle_root(transactions):
    if not transactions:
        return sha256_hash("")
    hashes = [sha256_hash(tx) for tx in transactions]
    while len(hashes) > 1:
        if len(hashes) % 2 == 1:
            hashes.append(hashes[-1])
        hashes = [sha256_hash(hashes[i] + hashes[i+1]) for i in range(0, len(hashes), 2)]
    return hashes[0]
