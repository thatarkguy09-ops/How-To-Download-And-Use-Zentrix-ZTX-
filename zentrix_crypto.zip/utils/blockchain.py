import time
import json
import threading
from .block import Block
from .transaction import Transaction
from .crypto_utils import sha256_hash

class Blockchain:
    def __init__(self):
        self.chain = []
        self.pending_transactions = []
        self.nodes = set()
        self.difficulty = 4
        self.mining_reward = 100
        self.block_time_target = 10
        self.difficulty_adjustment_blocks = 10
        self.lock = threading.Lock()

        # Zentrix (ZTX) Configuration
        self.token_name = "Zentrix"
        self.token_symbol = "ZTX"
        self.base_price = 0.01
        self.price_multiplier = 0.0001
        self.total_supply = 0
        self.market_cap = 0

        # Liquidity Pool for DEX
        self.liquidity_ztx = 10000
        self.liquidity_usd = 1000
        self.constant_product = self.liquidity_ztx * self.liquidity_usd

        self.create_genesis_block()
        self.update_price()

    def create_genesis_block(self):
        genesis = Block(0, [], time.time(), "0")
        genesis.mine_block(self.difficulty)
        self.chain.append(genesis)

    def get_latest_block(self):
        return self.chain[-1]

    def get_next_block_template(self, miner_address):
        with self.lock:
            coinbase_tx = {
                'sender': '0',
                'recipient': miner_address,
                'amount': self.mining_reward + sum(tx.get('fee', 0) for tx in self.pending_transactions),
                'fee': 0,
                'timestamp': time.time(),
                'signature': None,
                'tx_id': sha256_hash(f"coinbase-{time.time()}-{miner_address}"),
                'type': 'coinbase'
            }

            transactions = [coinbase_tx] + self.pending_transactions[:50]

            return {
                'index': len(self.chain),
                'transactions': transactions,
                'previous_hash': self.get_latest_block().hash,
                'difficulty': self.difficulty,
                'timestamp': time.time(),
                'reward': self.mining_reward,
                'token': self.token_symbol
            }

    def update_price(self):
        self.total_supply = sum(
            tx['amount'] for block in self.chain 
            for tx in block.transactions 
            if tx['sender'] == '0'
        )

        self.current_price = self.base_price + (self.total_supply * self.price_multiplier)
        self.market_cap = self.total_supply * self.current_price

        if self.liquidity_ztx > 0:
            self.dex_price = self.liquidity_usd / self.liquidity_ztx
        else:
            self.dex_price = self.current_price

    def get_price_data(self):
        self.update_price()
        return {
            'token': self.token_symbol,
            'name': self.token_name,
            'price_usd': round(self.current_price, 4),
            'dex_price': round(self.dex_price, 4),
            'total_supply': self.total_supply,
            'market_cap': round(self.market_cap, 2),
            'liquidity_ztx': self.liquidity_ztx,
            'liquidity_usd': self.liquidity_usd
        }

    def submit_block(self, block_data):
        with self.lock:
            block = Block.from_dict(block_data)

            if block.index != len(self.chain):
                return False, "Invalid block index"

            if not block.hash.startswith("0" * self.difficulty):
                return False, "Invalid proof of work"

            if block.previous_hash != self.get_latest_block().hash:
                return False, "Invalid previous hash"

            for tx_data in block.transactions:
                if tx_data['sender'] != '0':
                    tx = Transaction.from_dict(tx_data)
                    if not tx.is_valid():
                        return False, f"Invalid transaction: {tx.tx_id}"

            self.chain.append(block)

            confirmed_ids = {tx['tx_id'] for tx in block.transactions}
            self.pending_transactions = [
                tx for tx in self.pending_transactions 
                if tx.get('tx_id') not in confirmed_ids
            ]

            self.update_price()
            self.adjust_difficulty()

            return True, "Block accepted"

    def adjust_difficulty(self):
        if len(self.chain) % self.difficulty_adjustment_blocks == 0 and len(self.chain) > 0:
            actual_time = self.chain[-1].timestamp - self.chain[-self.difficulty_adjustment_blocks].timestamp
            expected_time = self.block_time_target * self.difficulty_adjustment_blocks

            ratio = actual_time / expected_time

            if ratio < 0.8:
                self.difficulty += 1
            elif ratio > 1.2 and self.difficulty > 1:
                self.difficulty -= 1

    def add_transaction(self, transaction):
        with self.lock:
            if not transaction.is_valid():
                return False, "Invalid transaction signature"

            if transaction.sender != "0" and self.get_balance(transaction.sender) < transaction.amount + transaction.fee:
                return False, "Insufficient balance"

            self.pending_transactions.append(transaction.to_dict())
            return True, transaction.tx_id

    def get_balance(self, address):
        balance = 0
        for block in self.chain:
            for tx in block.transactions:
                if tx['recipient'] == address:
                    balance += tx['amount']
                if tx['sender'] == address:
                    balance -= (tx['amount'] + tx.get('fee', 0))
        return balance

    def swap_ztx_to_usd(self, ztx_amount):
        if ztx_amount <= 0 or ztx_amount >= self.liquidity_ztx:
            return None, "Invalid amount or insufficient liquidity"

        new_ztx = self.liquidity_ztx + ztx_amount
        new_usd = self.constant_product / new_ztx
        usd_out = self.liquidity_usd - new_usd

        self.liquidity_ztx = new_ztx
        self.liquidity_usd = new_usd

        return usd_out, "Success"

    def swap_usd_to_ztx(self, usd_amount):
        if usd_amount <= 0 or usd_amount >= self.liquidity_usd:
            return None, "Invalid amount or insufficient liquidity"

        new_usd = self.liquidity_usd + usd_amount
        new_ztx = self.constant_product / new_usd
        ztx_out = self.liquidity_ztx - new_ztx

        self.liquidity_usd = new_usd
        self.liquidity_ztx = new_ztx

        return ztx_out, "Success"

    def is_chain_valid(self):
        for i in range(1, len(self.chain)):
            current = self.chain[i]
            previous = self.chain[i-1]

            if current.hash != current.calculate_hash():
                return False
            if current.previous_hash != previous.hash:
                return False
            if not current.hash.startswith("0" * self.difficulty):
                return False
        return True

    def resolve_conflicts(self, other_chains):
        new_chain = None
        max_length = len(self.chain)

        for chain in other_chains:
            if len(chain) > max_length and self.is_valid_chain(chain):
                max_length = len(chain)
                new_chain = chain

        if new_chain:
            self.chain = [Block.from_dict(b) for b in new_chain]
            self.update_price()
            return True
        return False

    def is_valid_chain(self, chain_data):
        if len(chain_data) == 0:
            return False

        if chain_data[0]['previous_hash'] != "0":
            return False

        for i in range(1, len(chain_data)):
            current = chain_data[i]
            previous = chain_data[i-1]

            if current['previous_hash'] != previous['hash']:
                return False
            if not current['hash'].startswith("0" * self.difficulty):
                return False
        return True

    def to_dict(self):
        return {
            'chain': [block.to_dict() for block in self.chain],
            'pending_transactions': self.pending_transactions,
            'difficulty': self.difficulty,
            'length': len(self.chain),
            'token': self.token_symbol,
            'price_data': self.get_price_data()
        }
