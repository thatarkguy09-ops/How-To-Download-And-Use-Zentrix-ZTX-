import requests
import threading
import time
import json

class P2PNetwork:
    def __init__(self, node_address):
        self.node_address = node_address
        self.peers = set()
        self.lock = threading.Lock()

    def register_node(self, address):
        with self.lock:
            if address != self.node_address:
                self.peers.add(address)
                return True
        return False

    def broadcast_block(self, block):
        with self.lock:
            peers = list(self.peers)

        for peer in peers:
            try:
                url = f"{peer}/submit"
                requests.post(url, json=block.to_dict(), timeout=5)
            except:
                pass

    def broadcast_transaction(self, transaction):
        with self.lock:
            peers = list(self.peers)

        for peer in peers:
            try:
                url = f"{peer}/tx"
                requests.post(url, json=transaction.to_dict(), timeout=5)
            except:
                pass

    def sync_chains(self, blockchain):
        with self.lock:
            peers = list(self.peers)

        longest_chains = []
        for peer in peers:
            try:
                response = requests.get(f"{peer}/chain", timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    longest_chains.append(data['chain'])
            except:
                pass

        if longest_chains:
            return blockchain.resolve_conflicts(longest_chains)
        return False

    def discover_peers(self, seed_node):
        try:
            response = requests.get(f"{seed_node}/nodes", timeout=5)
            if response.status_code == 200:
                nodes = response.json()
                for node in nodes.get('nodes', []):
                    self.register_node(node)
        except:
            pass

    def get_peers(self):
        with self.lock:
            return list(self.peers)

    def remove_peer(self, address):
        with self.lock:
            if address in self.peers:
                self.peers.remove(address)
