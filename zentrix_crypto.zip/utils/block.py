import time
import json
from .crypto_utils import sha256_hash, merkle_root

class Block:
    def __init__(self, index, transactions, timestamp, previous_hash, nonce=0, hash=None):
        self.index = index
        self.transactions = transactions
        self.timestamp = timestamp
        self.previous_hash = previous_hash
        self.nonce = nonce
        self.hash = hash if hash else self.calculate_hash()
        self.merkle_root = self.calculate_merkle_root()

    def calculate_hash(self):
        block_string = json.dumps({
            'index': self.index,
            'transactions': self.transactions,
            'timestamp': self.timestamp,
            'previous_hash': self.previous_hash,
            'nonce': self.nonce
        }, sort_keys=True)
        return sha256_hash(block_string)

    def calculate_merkle_root(self):
        return merkle_root(self.transactions)

    def mine_block(self, difficulty):
        target = "0" * difficulty
        while not self.hash.startswith(target):
            self.nonce += 1
            self.hash = self.calculate_hash()
        return self.hash

    def to_dict(self):
        return {
            'index': self.index,
            'transactions': self.transactions,
            'timestamp': self.timestamp,
            'previous_hash': self.previous_hash,
            'nonce': self.nonce,
            'hash': self.hash,
            'merkle_root': self.merkle_root
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            index=data['index'],
            transactions=data['transactions'],
            timestamp=data['timestamp'],
            previous_hash=data['previous_hash'],
            nonce=data['nonce'],
            hash=data['hash']
        )

    def is_valid(self, difficulty, previous_hash):
        if self.previous_hash != previous_hash:
            return False
        if not self.hash.startswith("0" * difficulty):
            return False
        if self.hash != self.calculate_hash():
            return False
        return True
