#!/usr/bin/env python3
"""Zentrix (ZTX) Miner"""

import argparse
import hashlib
import json
import time
import threading
import requests

try:
    import numba
    from numba import cuda
    CUDA_AVAILABLE = True
except ImportError:
    CUDA_AVAILABLE = False

class Miner:
    def __init__(self, node_url, miner_address, threads=None, use_gpu=False):
        self.node_url = node_url
        self.miner_address = miner_address
        self.threads = threads or 4
        self.use_gpu = use_gpu and CUDA_AVAILABLE
        self.stats = {'hashes': 0, 'blocks_found': 0, 'start_time': time.time()}
        self.running = True

        print(f"[+] Zentrix (ZTX) Miner initialized")
        print(f"[+] Threads: {self.threads}")
        print(f"[+] GPU: {'Enabled' if self.use_gpu else 'Disabled'}")

    def get_work(self):
        try:
            response = requests.get(f"{self.node_url}/getwork", params={'address': self.miner_address}, timeout=10)
            if response.status_code == 200:
                return response.json()
        except Exception as e:
            print(f"[!] Failed to get work: {e}")
        return None

    def submit_block(self, block_data):
        try:
            response = requests.post(f"{self.node_url}/submit", json=block_data, timeout=10)
            if response.status_code == 201:
                result = response.json()
                print(f"\n[***] BLOCK FOUND! #{result['block_index']}")
                print(f"[***] Hash: {result['hash'][:20]}...")
                self.stats['blocks_found'] += 1
                return True
            else:
                print(f"[!] Block rejected: {response.json().get('error', 'Unknown')}")
        except Exception as e:
            print(f"[!] Submit failed: {e}")
        return False

    def calculate_hash(self, block_template, nonce):
        block_string = json.dumps({
            'index': block_template['index'],
            'transactions': block_template['transactions'],
            'timestamp': block_template['timestamp'],
            'previous_hash': block_template['previous_hash'],
            'nonce': nonce
        }, sort_keys=True)
        return hashlib.sha256(block_string.encode()).hexdigest()

    def mine_worker(self, block_template, difficulty, start_nonce, step_size, result_queue):
        import queue as q
        target = "0" * difficulty
        nonce = start_nonce

        while self.running:
            hash_result = self.calculate_hash(block_template, nonce)
            self.stats['hashes'] += 1

            if hash_result.startswith(target):
                result_queue.put((nonce, hash_result))
                return

            nonce += step_size

    def mine(self):
        print("\n[+] Starting ZTX mining loop...")
        print("[+] Press Ctrl+C to stop\n")

        import queue

        while self.running:
            work = self.get_work()
            if not work:
                time.sleep(5)
                continue

            difficulty = work['difficulty']
            print(f"[+] Mining block #{work['index']} | Difficulty: {difficulty} | Reward: {work['reward']} ZTX")

            result_queue = queue.Queue()
            threads = []

            for i in range(self.threads):
                t = threading.Thread(target=self.mine_worker, args=(work, difficulty, i, self.threads, result_queue))
                t.daemon = True
                t.start()
                threads.append(t)

            try:
                nonce, hash_result = result_queue.get(timeout=300)

                block = {
                    'index': work['index'],
                    'transactions': work['transactions'],
                    'timestamp': work['timestamp'],
                    'previous_hash': work['previous_hash'],
                    'nonce': nonce,
                    'hash': hash_result
                }

                if self.submit_block(block):
                    elapsed = time.time() - self.stats['start_time']
                    hps = self.stats['hashes'] / elapsed if elapsed > 0 else 0
                    print(f"[+] Hash rate: {hps:.2f} H/s | Total ZTX blocks: {self.stats['blocks_found']}\n")

            except queue.Empty:
                print("[!] Timeout, fetching new work...")

            self.running = False
            for t in threads:
                t.join(timeout=1)
            self.running = True

def main():
    parser = argparse.ArgumentParser(description='Zentrix (ZTX) Miner')
    parser.add_argument('--node', default='http://localhost:5000')
    parser.add_argument('--address', required=True)
    parser.add_argument('--threads', type=int)
    parser.add_argument('--gpu', action='store_true')

    args = parser.parse_args()

    miner = Miner(args.node, args.address, args.threads, args.gpu)

    try:
        miner.mine()
    except KeyboardInterrupt:
        print("\n[!] Stopping miner...")
        miner.running = False

if __name__ == "__main__":
    main()
