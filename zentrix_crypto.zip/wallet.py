#!/usr/bin/env python3
"""Zentrix (ZTX) Wallet"""

import argparse
import json
import os
import requests
from utils import generate_keypair, sign_transaction

WALLET_FILE = "wallet.json"

def create_wallet():
    keys = generate_keypair()
    wallet_data = {
        'private_key': keys['private_key'],
        'public_key': keys['public_key'],
        'address': keys['public_key']
    }

    with open(WALLET_FILE, 'w') as f:
        json.dump(wallet_data, f, indent=2)

    print(f"Zentrix (ZTX) Wallet created!")
    print(f"Address: {wallet_data['address'][:50]}...")
    print(f"Saved to {WALLET_FILE}")
    return wallet_data

def load_wallet():
    if not os.path.exists(WALLET_FILE):
        return create_wallet()
    with open(WALLET_FILE, 'r') as f:
        return json.load(f)

def get_balance(node_url, address):
    try:
        response = requests.post(f"{node_url}/balance", json={'address': address})
        if response.status_code == 200:
            return response.json()['balance']
    except:
        pass
    return 0

def get_price_data(node_url):
    try:
        response = requests.get(f"{node_url}/price")
        if response.status_code == 200:
            return response.json()
    except:
        pass
    return None

def send_transaction(node_url, recipient, amount, fee=0.001):
    wallet = load_wallet()

    tx_data = {
        'sender': wallet['address'],
        'recipient': recipient,
        'amount': float(amount),
        'fee': float(fee),
        'timestamp': time.time()
    }

    signature = sign_transaction(wallet['private_key'], tx_data)
    tx_data['signature'] = signature

    try:
        response = requests.post(f"{node_url}/tx", json=tx_data)
        if response.status_code == 201:
            result = response.json()
            print(f"Transaction sent!")
            print(f"Tx ID: {result['tx_id']}")
        else:
            print(f"Error: {response.json()['message']}")
    except Exception as e:
        print(f"Failed to send: {e}")

def main():
    import time
    parser = argparse.ArgumentParser(description='Zentrix (ZTX) Wallet')
    parser.add_argument('--node', default='http://localhost:5000')
    parser.add_argument('command', choices=['create', 'balance', 'send', 'address', 'price'])
    parser.add_argument('--to')
    parser.add_argument('--amount', type=float)
    parser.add_argument('--fee', type=float, default=0.001)

    args = parser.parse_args()

    if args.command == 'create':
        create_wallet()
    elif args.command == 'address':
        wallet = load_wallet()
        print(f"Address: {wallet['address']}")
    elif args.command == 'balance':
        wallet = load_wallet()
        balance = get_balance(args.node, wallet['address'])
        print(f"Balance: {balance} ZTX")
    elif args.command == 'price':
        wallet = load_wallet()
        balance = get_balance(args.node, wallet['address'])
        price_data = get_price_data(args.node)
        if price_data:
            value = balance * price_data['price_usd']
            print(f"\nZentrix (ZTX) Market Data:")
            print(f"Price: ${price_data['price_usd']:.4f}")
            print(f"Your Balance: {balance} ZTX")
            print(f"USD Value: ${value:.2f}")
            print(f"Market Cap: ${price_data['market_cap']:,.2f}")
        else:
            print("Failed to get price data")
    elif args.command == 'send':
        if not args.to or args.amount is None:
            print("Usage: wallet.py send --to <address> --amount <amount>")
            return
        send_transaction(args.node, args.to, args.amount, args.fee)

if __name__ == "__main__":
    main()
